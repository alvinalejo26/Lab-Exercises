#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	cout<<"Enter a word: ";
	char word[100];
	cin>>word;
	
	int x = 0;
	int letters= strlen(word)-1;
	
	for (x=0;x<letters;x++)
		{
			if (word[x] !=word[letters])
				{
					cout<<word<<" is not a palindrome";
					exit (1);
				}
			letters--;
		}
		
		cout<<word<<" is a palindrome";
}
