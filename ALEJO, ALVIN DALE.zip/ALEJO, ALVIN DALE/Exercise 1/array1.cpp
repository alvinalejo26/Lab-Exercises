#include <iostream>
#include <conio.h>


using namespace std;

 

int  main ()

{   

	int x, y, z;

    int array [10];

    for (x=0; x<10; x++)

    	{

        cout << "Enter integer number: " ;
        	for (int x = 1; x<=10;x++){
	while(!(cin>> array[x])){
		cout<<"Invalid input try again."<<endl;
		cin.clear();
		cin.sync();
		}	

        cin >> array[x];

    	}

    for (x=0; x<10; x++)

        {

            for (y=0; y<9; y++)

                {

                    if(array[y]>array[y+1])

                        	{

                				z=array[y];

                				array[y]=array[y+1];

                				array[y+1]=z;

                        	}

                }

        }

    cout << "The integers in ascending order are : ";

        for (x=0;x<10;x++)

        { 

           cout <<"\n";

           cout <<array[x];

           cout << "\n";

        }

     system ("pause");

        return 0; 

    }
}

