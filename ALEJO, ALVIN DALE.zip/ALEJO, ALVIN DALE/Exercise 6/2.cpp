#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	fp=fopen("d:\\myfiles\\sample.txt", "r");
	if(!fp)
	{
		cout << "Cannot open file.\n";
		system("pause");
		exit(1);
	}
	//Get each character from the file and prints to the screen
	//until it reach the end of file (EOF)
	char c;
	while((c = fgetc(fp))!=EOF)
		
	fclose(fp);
	system("pause > 0");
	return 0;
}
