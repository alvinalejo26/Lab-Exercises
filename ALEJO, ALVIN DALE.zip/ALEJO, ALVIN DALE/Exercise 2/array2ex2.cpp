#include <iostream>
#include <math.h>

using namespace std;

int main()
{

	int a, fact=1, number; 
		cout<<"Enter any number \n";
		entnum:
		cin>>number;
			if (number <=0 || cin.get() != '\n')
				{
					cout<<"Invalid input, try again"<<endl;
					cin.clear();
					cin.sync();
					goto entnum;
				}
					
			else {
					for (a=1; a<=number; a++)
						{
							fact = fact * a;
						}
					cout<<" \n Factorial of " <<number<<" is: " <<fact<<endl;
						}
}
