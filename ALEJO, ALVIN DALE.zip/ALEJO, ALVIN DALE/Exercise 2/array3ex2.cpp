#include <iostream>

using namespace std;

	int max (int num1, int num2){
	int ans;
	
		if(num1>num2){
			ans = num1;
		}
		else{
			ans = num2;
		}
	}
	
	int main(){
		int fnum,snum;
		cout<<"Enter first number: " << endl;
		cin>>fnum;
		cout<<"Enter second number: "<< endl;
		cin>>snum;
		cout<<"The greatest number is "<< max(fnum,snum)<<endl;		
	}
