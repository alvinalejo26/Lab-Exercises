#include<iostream>
#include<string.h>
using namespace std;

int main(){
	
	char wordA[20],wordB[20];
	int result;
	
	cout << "******************************\n";
	cout << "\tSTRING COMPARE\n";
	cout << "******************************\n";
	cout << "Enter a first word:";
	cin.getline(wordA,20);
	cout << "Enter a second word:";
	cin.getline(wordB,20);
	
	result = strcmp(wordA,wordB);
	
	switch(result){
		case 1: cout << "Positive"; break;
		case 0:	cout << "Equal"; break;
		case-1: cout << "Negative"; break;
	}
}
